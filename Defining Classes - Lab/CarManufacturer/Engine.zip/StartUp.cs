﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string make = Console.ReadLine();
            string model = Console.ReadLine();
            int year = int.Parse(Console.ReadLine());
            double fuelQuantity = double.Parse(Console.ReadLine());
            double fuelConsumption = double.Parse(Console.ReadLine());

            //Car firstCar = new Car();
            //Car secondCar = new Car(make, model, year);
            //Car thirdCar = new Car(make, model, year, fuelQuantity, fuelConsumption);
            //Console.WriteLine(firstCar.WhoAmI());
            //Console.WriteLine();
            //Console.WriteLine(secondCar.WhoAmI());
            //Console.WriteLine();
            //Console.WriteLine(thirdCar.WhoAmI());
            //Console.WriteLine();

            Tire[] lamboTires = new Tire[]
            {
                new Tire(2018, 2.4),
                new Tire(2018, 2.5),
                new Tire(2018, 2.4),
                new Tire(2018, 2.5),
            };

            Engine lamboEngine = new Engine(560, 4300);

            Car lamboCar = new Car("Lamborghini", "Ursus", 2015, 80, 0.12, lamboEngine, lamboTires);
            lamboCar.Drive(50);
            Console.WriteLine(lamboCar.WhoAmI());
            Console.WriteLine();

            //Car car = new Car();

            //car.Make = "VW";
            //car.Model = "MK3";
            //car.Year = 1992;
            //car.FuelQuantity = 200;
            //car.FuelConsumption = 200;
            //car.Drive(2000);
            //Console.WriteLine(car.WhoAmI());

            //Console.WriteLine($"Make: {car.Make}\nModel: {car.Model}\nYear: {car.Year}");
        }
    }
}
