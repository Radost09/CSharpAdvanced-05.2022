﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericBoxOfString
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] personInfo = Console.ReadLine().Split();
            string fullName = personInfo[0] + " " + personInfo[1];
            string city = personInfo[2];
            Tuple<string, string> firstTuple = new Tuple<string, string>(fullName, city);
            Console.WriteLine(firstTuple);

            string[] nameAndBeer = Console.ReadLine().Split();
            string name = nameAndBeer[0];
            int littreBeer = int.Parse(nameAndBeer[1]);
            Tuple<string, int> secondTuple = new Tuple<string, int>(name, littreBeer);
            Console.WriteLine(secondTuple);
 
            var numbers = Console.ReadLine().Split();
            int numberOne = int.Parse(numbers[0]);
            double numberTwo = double.Parse(numbers[1]);
            Tuple<int, double> thirdTuple = new Tuple<int, double>(numberOne, numberTwo);
            Console.WriteLine(thirdTuple);
        //    int numToRead = int.Parse(Console.ReadLine());
        //    List<Box<double>> boxes = new List<Box<double>>();

        //    for (int i = 0; i < numToRead; i++)
        //    {
        //        double text = double.Parse(Console.ReadLine());
        //        boxes.Add(new Box<double>(text));
        //    }
        //    double itemToCompare = double.Parse(Console.ReadLine());
        //    Console.WriteLine(CompareItems(boxes, itemToCompare));
        //}

        //public static double CompareItems<T>(List<Box<T>> boxes, T item)
        //    where T : IComparable<T>
        //{
        //    int count = 0;

        //    foreach (var box in boxes)
        //    {
        //        if(box.CompareTo(item) > 0)
        //        {
        //            count++;
        //        }
        //    }
        //    return count;
        }
    }
}
