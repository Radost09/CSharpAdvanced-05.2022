﻿using System;

namespace GenericScale
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var equals = EqualityScale<string>.AreEqual("Pesho", "Gosho");
            Console.WriteLine(equals);

        }
    }
}
