﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //Person firstPerson = new Person();
            //Person secondPerson = new Person(43);
            //Person thirdPerson = new Person("George", 20);

            //family.AddMember(firstPerson);
            //family.AddMember(secondPerson);
            //family.AddMember(thirdPerson);

            Family family = new Family();
            List<Person> personList = new List<Person>();

            int numOfPeople = int.Parse(Console.ReadLine());
            for (int i = 1; i <= numOfPeople; i++)
            {
                string peopleInfo = Console.ReadLine();
                string name = peopleInfo.Split()[0];
                int age = int.Parse(peopleInfo.Split()[1]);

                Person person = new Person(name, age);

                if(person.Age > 30)
                {
                    personList.Add(person);
                }
                
            }
            //Person oldestFamilyMember = family.GetOldestMember();
            var printInOrder = personList.Where(p => p.Age > 30).OrderBy(p => p.Name);

            foreach (var person in printInOrder)
            {

                Console.WriteLine(string.Join(" - ", person.Name, person.Age));
            }
            //Console.WriteLine(string.Join(" - ", oldestFamilyMember.Name, oldestFamilyMember.Age));

            //Console.WriteLine($"Name: {firstPerson.Name} Age: {firstPerson.Age}");
            //Console.WriteLine($"Name: {secondPerson.Name} Age: {secondPerson.Age}");
            //Console.WriteLine($"Name: {thirdPerson.Name} Age: {thirdPerson.Age}");
        }
    }
}
