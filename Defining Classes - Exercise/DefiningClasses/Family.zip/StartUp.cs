﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //Person firstPerson = new Person();
            //Person secondPerson = new Person(43);
            //Person thirdPerson = new Person("George", 20);

            //family.AddMember(firstPerson);
            //family.AddMember(secondPerson);
            //family.AddMember(thirdPerson);

            Family family = new Family();

            int numOfPeople = int.Parse(Console.ReadLine());
            for (int i = 1; i <= numOfPeople; i++)
            {
                string peopleInfo = Console.ReadLine();
                string name = peopleInfo.Split()[0];
                int age = int.Parse(peopleInfo.Split()[1]);

                Person person = new Person(name, age);
                family.AddMember(person);
            }
            Person oldestFamilyMember = family.GetOldestMember();
            Console.WriteLine($"{oldestFamilyMember.Name} {oldestFamilyMember.Age}");

            //Console.WriteLine($"Name: {firstPerson.Name} Age: {firstPerson.Age}");
            //Console.WriteLine($"Name: {secondPerson.Name} Age: {secondPerson.Age}");
            //Console.WriteLine($"Name: {thirdPerson.Name} Age: {thirdPerson.Age}");
        }
    }
}
